import static java.lang.Math.*;
import static java.lang.Math.cos;

public class FindCountPursuersBetaAboveZero {
    public static double[] firstPursuer(double r, double l, double alpha ) {
        double phi = asin((r - l) / (r + l)); // phi в радианах
        double phiInDeg = Math.toDegrees(phi); // Угол в градусах
        double xs = -(r + l) + sin(phi) * l;
        double ys = -cos(phi) * l;
        double k = tan(phi);
        double a = (1 + pow(k, 2));
        double b = 2 * (pow(k, 2) * (r + l + sin(phi) * l) - k * cos(phi) * l);
        double c = pow(k, 2) * pow((r + l + sin(phi) * l), 2) + pow(cos(phi) * l, 2) - 2 * k * cos(phi) * l * (r + l + sin(phi) * l) - pow(r, 2);
        double Bx = (-b + sqrt(pow(b, 2) - 4 * a * c)) / (2 * a);
        double By = k * (Bx + r + l + sin(phi) * l) - cos(phi) * l;
        double Ax = (-b - sqrt(pow(b, 2) - 4 * a * c)) / (2 * a);
        double Ay = k * (Ax + r + l + sin(phi) * l) - cos(phi) * l;
        return new double[]{phi, Ax, Ay, Bx, By};
    }


    public static int findCountPursuersBZ(double r, double l, double alpha, double beta) {
        int k;
        if (r * +beta * (r + l) / alpha < l) {
            k = 1;
        } else {
            k = 2;

        }
        return k;
    }

    public static void main(String[] args) {

    }
}
